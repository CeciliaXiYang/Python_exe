#!/bin/bash

mkdir data/

mkdir results/

mkdir saved_models/
mkdir saved_models/reddit/
mkdir saved_models/wikipedia/
mkdir saved_models/mooc/
mkdir saved_models/lastfm/


