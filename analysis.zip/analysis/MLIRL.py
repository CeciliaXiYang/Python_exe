#!/usr/bin/env python
# coding: utf-8


import numpy as np
import random
import copy


# Get the weights for different demos
# - Method 1: All demos have the same weights
# - Method 2: Normalize the frequency of occurrence as weights
def DemoWeights(demos, para):
    if para['MLIRL_weight'] == 'ones':
        weights = np.ones([len(demos)]) * para['MLIRL_w'] #/ len(demos) REVISED HERE (02/12/2020)

    elif para['MLIRL_weight'] == 'freq':
        # Get the unique demos and their counts
        demos_trajs = [list(demos[i][1]) for i in range(len(demos))]
        unique_demos, unique_counts = np.unique(demos_trajs, return_counts=True)

        # Get frequency of demos
        unique_freqs = unique_counts / np.sum(unique_counts)

        w = np.zeros([len(demos_trajs)])
        for idx in range(len(unique_demos)):
            tmp = [i for i, x in enumerate(demos_trajs) if x == unique_demos[idx]]
            w[tmp] = unique_freqs[idx]

        # Normalize the weights
        weights = np.exp(w) / np.sum(np.exp(w))

    return weights


def MLIRLLikelihood(demos, w, theta, Q_, para):
    # Set up the environment parameters
    nS = para['n_states']
    nA = para['n_actions']
    nF = np.shape(para['feat_map'])[0]
    gamma = para['GAMMA']

    ### TODO: Move to initialization part
    para['MLIRL_weight'] = 'ones'  # 'ones' / 'freq'
    QLITERS = para['MLIRL_QLITERS']
    EPS = 1e-12
    beta = 0.5  # 0.5

    # Initialize the reward
    feat_map = para['feat_map']
    rewards = feat_map.dot(theta).reshape((nF,))

    # -----------------------------------------------------------------------------------------------
    # Initialize the Q table
    Q = copy.deepcopy(Q_)

    # Calculate the Q values
    for t in range(QLITERS):
        # Calculate the Q value
        # Note: 'max' in standard Bellman equation is replaced with an operator that blends values
        # via Boltzmann exploration, which makes the likelihood differentiable (John, 1994)
        # John, George H. "When the best move isn't optimal: Q-learning with exploration." AAAI. 1994.
        BQ = np.exp(beta * Q)  # Q(s,a)
        BQS = np.sum(BQ, axis=1)
        BQS = np.expand_dims(BQS, axis=1) * np.ones([nS, nA])  # exp(beta * Q(s,a))
        NBQ = gamma * np.sum((Q * BQ / BQS), axis=1)  # sum(exp(beta * Q(s,a)))

        oldQ = copy.deepcopy(Q)

        # Expected future rewards
        future_rwd = np.array([np.sum(para['transitions'][:, a, :] * NBQ, axis=1).tolist() for a in range(nA)]).T

        # Immediate rewards
        if para['reward_pattern'] == 'S':
            immediate_rwd = np.expand_dims(rewards, axis=1) * np.ones([nS, nA])
        elif para['reward_pattern'] == 'SA':
            immediate_rwd = np.reshape(rewards, (nS, nA), order='F')

        # Update the Q table
        Q = immediate_rwd + future_rwd

        # Check the convergence
        if np.max(np.abs(Q - oldQ)) < EPS:
            break

    # Generate the policy (i.e., P(a|s))
    BQ = np.exp(beta * Q)  # Get Q(s,a)
    BQS = np.sum(BQ, axis=1)
    BQS = np.expand_dims(BQS, axis=1) * np.ones([nS, nA])  # Get exp(beta * Q(s,a))
    piL = BQ / BQS

    # Compute likelihood
    llh = 0
    for idx in range(len(demos)):
        llh += w[idx] * np.sum([piL[s][a] for (s, a) in demos[idx][1]])

    # Calculate dQ/dw
    diffQ = Q - Q_
    diffQ = np.reshape(diffQ, [nS * nA], order='F')  # Difference of Q values

    if para['reward_pattern'] == 'S':
        phi_SA = feat_map.T
        for i in range(nA - 1):
            phi_SA = np.concatenate((phi_SA, feat_map.T), axis=1)  # Get nF * (nS * nA) mapping
    elif para['reward_pattern'] == 'SA':
        phi_SA = feat_map.T

    dQ = phi_SA * diffQ

    # Calculate dlogPi/dw
    dlogPi = np.zeros([nF, nS * nA])
    for f in range(nF):
        x = np.reshape(dQ[f, :], (nS, nA), order='F')
        y = piL * x
        z = beta * (x - y)
        dlogPi[f] = np.reshape(z, (1, nS * nA), order='F')

    grad = np.zeros(nF)
    # Calculate gradient of reward function
    for idx in range(len(demos)):
        tmp_sa = [a * nS + s for (s, a) in demos[idx][1]]  # [(a - 1) * nS + s for (s, a) in demos[idx][1]]
        grad += w[idx] * np.sum(dlogPi[:, tmp_sa], axis=1)

    # Clip the gradient
    clip_val = para['MLIRL_clip'] # 5 REVISED HERE (02/09/2020)
    for j in range(len(grad)):
        if grad[j] > clip_val:
            grad[j] = clip_val

    return Q, llh, grad


def MLIRL(demos, w, para):
    MLIRL_ITERS = para['MLIRL_ITERS']
    # Learning rate
    # Method 1: Fixed - [0.5]*para['MLIRL_ITERS']
    # Method 2: Decayed - [0.1 * np.exp(-i*0.01) for i in range(para['MLIRL_ITERS'])]
    lr = [0.5] * para['MLIRL_ITERS']

    # Initialize the reward parameters
    theta = np.random.uniform(size=(np.shape(para['feat_map'])[0],))
    Q_ = np.zeros([para['n_states'], para['n_actions']])

    count, llh_list, grad_list = 0, [], []

    while count < MLIRL_ITERS:
        Q, llh, grad = MLIRLLikelihood(demos, w, theta, Q_, para)
        theta += lr[count] * grad

        llh_list.append(llh)
        grad_list.append(np.mean(grad))
        count += 1
        Q_ = Q

        if count % 10 == 0:
            print('iteration {}: llh = {}'.format(count, llh))
            print('-------------------------------------')

    reward = para['feat_map'].dot(theta).reshape((np.shape(para['feat_map'])[0],))
    return reward, llh_list