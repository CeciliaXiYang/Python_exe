import numpy as np
import time
import copy

# from birl import *
# from maxent_irl import *
# from MaxEnt_Online import maxEntIRLRewards, maxEntIRLOnlineRewards
# from MaxMargin_Online import maxMarginIRLRewards, maxMarginIRLOnlineRewards
from MLIRL import MLIRL


def saveHist(data, hst, i, elapsed_T):
    # Belonging of trajectory & learned weights
    tmp_para = {}
    tmp_para['b'] = np.argmax(data['z'], 1)
    tmp_para['w'] = data['weight']

    hst['Cl'].append([tmp_para])
    hst['logPost'].append(data['L'])
    hst['elapsed_T'].append(elapsed_T)

    return hst


### Expectation step
# data -- stores the currently learned paras
def estep(demos, data, para):
    nTrajs = len(demos)
    nrCl = para['EMIRL_nrCl']

    # Calculate the log-likelihood trajectory belonging to a cluster
    logLLH = np.zeros([nTrajs, nrCl])
    for k in range(nrCl):
        theta = data['weight'][:, k]
        # logLLH[:,k] = sum_(s,a) log[pi_theta(k)(s,a)]
        # for m in range(nTrajs):
        #     w = DemoWeights(demos[m], para)
        #     logLLH[m, k] = calLogLLH_MLIRL(demos, w, theta, para) ###
        logLLH[:, k] = calLogLLH_MLIRL(demos, theta, para)  ###

    # Update the z
    z = np.zeros([nTrajs, nrCl])
    for m in range(nTrajs):
        for k in range(nrCl):
            z[m, k] = data['rho'][k] * np.exp(logLLH[m, k])

        # Normalization
        if sum(z[m, :]) > 0:
            z[m, :] = z[m, :] / sum(z[m, :])

    # Update the likelihood L
    L = 0
    L_list = []
    for m in range(nTrajs):
        for k in range(nrCl):
            if z[m, k] > 0:
                # tmp_1 = np.log(data['rho'][k]) + logLLH[m, k]
                # tmp_3 = tmp_1 * z[m, k]
                L += (np.log(data['rho'][k]) + logLLH[m, k]) * z[m, k]
                L_list.append((np.log(data['rho'][k]) + logLLH[m, k]) * z[m, k])

    return z, L


### Maximization step
def mstep(demos, data, para):
    nTrajs = len(demos)
    nrCl = para['EMIRL_nrCl']
    dim = np.shape(para['feat_map'])[1]

    # Update the rho
    # rho = sum_i (z_il /  N)
    rho = np.zeros([nrCl, 1])
    for k in range(nrCl):
        rho[k] = np.sum(data['z'][:, k])
    rho = rho / nTrajs

    # Update the weights
    # Compute theta_l via MLIRL on D with weight z_ij on trajectory kersi_i
    # Note: Here MLIRL can be replaced by other IRL methods
    weight = np.nan * np.ones(shape=(dim, nrCl))
    for k in range(nrCl):
        w = data['z'][:, k] / sum(data['z'][:, k])
        temp_reward, error = MLIRL(demos, w, para)
        weight[:, k] = temp_reward

    return rho, weight


def calLogLLH_MLIRL(demos, theta, para):
    # Set up the environment parameters
    nS = para['n_states']
    nA = para['n_actions']
    nF = np.shape(para['feat_map'])[0]
    gamma = para['GAMMA']

    ### TODO: Move to initialization part
    para['MLIRL_weight'] = 'ones'  # 'ones' / 'freq'
    QLITERS = para['MLIRL_QLITERS']
    EPS = 1e-12
    beta = 0.5  # 0.5

    # Initialize the reward
    feat_map = para['feat_map']
    rewards = feat_map.dot(theta).reshape((nF,))
    Q = np.zeros([para['n_states'], para['n_actions']])

    # -----------------------------------------------------------------------------------------------
    # Calculate the Q values
    for t in range(QLITERS):
        # Calculate the Q value
        # Note: 'max' in standard Bellman equation is replaced with an operator that blends values
        # via Boltzmann exploration, which makes the likelihood differentiable (John, 1994)
        # John, George H. "When the best move isn't optimal: Q-learning with exploration." AAAI. 1994.
        BQ = np.exp(beta * Q)  # Q(s,a)
        BQS = np.sum(BQ, axis=1)
        BQS = np.expand_dims(BQS, axis=1) * np.ones([nS, nA])  # exp(beta * Q(s,a))
        NBQ = gamma * np.sum((Q * BQ / BQS), axis=1)  # sum(exp(beta * Q(s,a)))

        oldQ = copy.deepcopy(Q)

        # Expected future rewards
        future_rwd = np.array([np.sum(para['transitions'][:, a, :] * NBQ, axis=1).tolist() for a in range(nA)]).T

        # Immediate rewards
        if para['reward_pattern'] == 'S':
            immediate_rwd = np.expand_dims(rewards, axis=1) * np.ones([nS, nA])
        elif para['reward_pattern'] == 'SA':
            immediate_rwd = np.reshape(rewards, (nS, nA), order='F')

        # Update the Q table
        Q = immediate_rwd + future_rwd

        # Check the convergence
        if np.max(np.abs(Q - oldQ)) < EPS:
            break

    # Generate the policy (i.e., P(a|s))
    BQ = np.exp(beta * Q)  # Get Q(s,a)
    BQS = np.sum(BQ, axis=1)
    BQS = np.expand_dims(BQS, axis=1) * np.ones([nS, nA])  # Get exp(beta * Q(s,a))
    piL = BQ / BQS

    # Compute likelihood
    llh_list = []
    for idx in range(len(demos)):
        llh_list.append(np.sum(np.log([piL[s][a] for (s, a) in demos[idx][1]])))  # REVISED HERE (02/03/2020)

    return llh_list


# Main framework of EM-IRL
def EM_IRL(demos, para):
    dim = np.shape(para['feat_map'])[1]
    nTrajs = len(demos)

    # Parameters
    nrCl = para['EMIRL_nrCl']
    maxIters = para['EMIRL_Iters']

    # -------------------------------------------------------
    # Initialize
    start_T = time.time()
    data = {}
    data['L'] = -np.inf

    ### Initialize rho and theta
    # rho_i: estimate for the prior probability of cluster i -- nrCl * 1
    # weight(theta): weight of features to get the reward -- dim * nrCl

    data['rho'] = np.ones([nrCl, 1]) / nrCl
    data['weight'] = np.nan * np.ones(shape=(dim, nrCl))
    for k in range(nrCl):
        data['weight'][:, k] = np.random.uniform(size=(dim,))

    ### Initialize z and L
    # z_il: probability that trajectory i is generated by cluster l -- nTrajs * nrCl
    # L: likelihood
    [z, L] = estep(demos, data, para)
    data['z'] = z
    data['L'] = L

    elapsed_T = (time.time() - start_T) / 60
    print('{}-th: {} {:.2f} min\n'.format(0, L, elapsed_T))

    # Save intermediate parameters to hst
    hst = {'Cl': [], 'logPost': [], 'elapsed_T': []}
    hst = saveHist(data, hst, 0, elapsed_T)

    # -------------------------------------------------------
    for i in range(maxIters):
        print('iter: ', i)
        # M-step
        [rho, weight] = mstep(demos, data, para)
        new_data = {}
        new_data['rho'] = rho
        new_data['weight'] = weight

        # E-step
        [z, L] = estep(demos, new_data, para)
        new_data['z'] = z
        new_data['L'] = L

        elapsed_T = (time.time() - start_T) / 60
        print('{}-th: {} {:.2f} min\n'.format(i+1, L, elapsed_T))

        # Check the convergence
        delta = new_data['L'] - data['L']

        if delta > 0:
            data = new_data
            if delta < 1e-12:  # 1e-4
                break
        # else:
        #     #     break

        if elapsed_T > para['EMIRL_maxTime']:
            print('Warning: Time out! \n')
            break

        # Save intermediate parameters to hst
        hst = saveHist(new_data, hst, i + 1, elapsed_T)

    # Solution with rho, weight, z, and L
    sol = data
    sol['belongTo'] = np.argmax(sol['z'], 1)  # Check the belongings of each trajectory
    logPost = data['L']
    # printClustAssign(sol.belongTo)

    return sol, hst, logPost
